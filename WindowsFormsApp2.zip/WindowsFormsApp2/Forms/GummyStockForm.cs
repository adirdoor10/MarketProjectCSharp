﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class GummyStockForm : Form
    {
        public GummyStockForm()
        {
            InitializeComponent();
        }

        private void GummyName_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (GummyName.Text == "" || GummyPrice.Text == "" || GummyWeight.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    int GummyPriceInt = 0, GummyWeightInt = 0;
                    bool alcohol = false;
                    
                    Int32.TryParse(GummyPrice.Text, out GummyPriceInt);
                    Int32.TryParse(GummyWeight.Text, out GummyWeightInt);
                    
                    Gummy myObj = new Gummy(GummyPriceInt, GummyName.Text, GummyWeightInt);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Hide();
            SnaksFormStock d = new SnaksFormStock();
            d.Show();
        }

        public void label1_Click(object sender, EventArgs e)
        {
            this.Hide();
            DrinksStockForm d = new DrinksStockForm();
            d.Show();
        }

        private void BillinkBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Billing d = new Billing();
            d.Show();
        }
    }
}
