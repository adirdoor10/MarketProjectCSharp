﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class SnaksFormStock : Form
    {
        public SnaksFormStock()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void drinksPrice_TextChanged(object sender, EventArgs e)
        {

        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (SnaksName.Text == "" || SnaksPrice.Text == "" || SnaksQuan.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    int snaksPriceInt = 0, snaksQuanInt=0;
                    bool snaksSour=false, snaksSweet=false;
                    if (SnaksSour.Checked)
                        snaksSour = true;
                    if (SnaksSweet.Checked)
                        snaksSweet =true;
                    Int32.TryParse(SnaksQuan.Text, out snaksQuanInt);
                    Int32.TryParse(SnaksPrice.Text, out snaksPriceInt);
                    Snaks myObj = new Snaks(snaksPriceInt, SnaksName.Text, snaksSour, snaksSweet, snaksQuanInt);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }

        }

        

        private void GummyBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            GummyStockForm d = new GummyStockForm();
            d.Show();
        }

        private void BillingBtn_Click(object sender, EventArgs e)
        {

            this.Hide();
            Billing d = new Billing();
            d.Show();

        }

        private void DrinksBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            DrinksStockForm d = new DrinksStockForm();
            d.Show();

        }
    }
}
