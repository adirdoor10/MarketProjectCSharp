﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class DrinksStockForm : Form
    {
        public DrinksStockForm()
        {
            InitializeComponent();
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (DrinksNames.Text == "" || DrinksLiter.Text == "" || DrinksQun.Text == ""||DrinksPrice.Text=="")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    int DrinksPriceInt = 0, DrinksQuanInt = 0, DrinksLiterInt=0;
                    bool alcohol = false;
                    if (DrinksIsAlc.Checked)
                        alcohol = true;
                    Int32.TryParse(DrinksPrice.Text, out DrinksPriceInt);
                    Int32.TryParse(DrinksLiter.Text, out DrinksLiterInt);
                    Int32.TryParse(DrinksQun.Text, out DrinksQuanInt);
                    Drinks myObj = new Drinks(DrinksLiterInt, DrinksQuanInt,DrinksPriceInt, DrinksNames.Text, alcohol);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }
    

        

        

        private void SnaksBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            SnaksFormStock d = new SnaksFormStock();
            d.Show();
        }

        private void GummyBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            GummyStockForm d = new GummyStockForm();
            d.Show();
        }

        private void BillingBtn_Click(object sender, EventArgs e)
        {
            
                this.Hide();
                Billing d = new Billing();
                d.Show();
            
        }
    }
}
