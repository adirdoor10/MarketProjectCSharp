﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace WindowsFormsApp2
{

     class Gummy : Food
    {

        public double _weight;
       
        public Gummy(int price, string productName,double weight)
        {
            _price = price;
            _ProductName = productName;
            _weight = weight;
            _ProductType = "Gummy";
            
            this.Add(this,amount);
        }
        public double Weight
        {
            get => _weight;
            set => _weight = value;

        }

    }
}
