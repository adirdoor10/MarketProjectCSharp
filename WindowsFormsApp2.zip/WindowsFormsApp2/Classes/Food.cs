﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsApp2
{
    class Food : Product
    {
        public double _calories;
        //public int _dateExpire;
        public Food()
        {

        }
        public Food(double calories, string picture)
        {
            _calories = calories;
            _picture = picture;
            
        }
        
        public double Calories
        {
            get => _calories;
            set => _calories = value;
        }
        

    }
}
