﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.Media;

namespace WindowsFormsApp2
{
    class Product : Stock

    {
        static int _amountProduct = 0;
        public int _amountToCreat;
        public int _price;
        public int _newid;
        public static int _id;
        public String _ProductName;
        public string _ProductType;
        public string _picture;
        
        //public Product[]_Parray;

        public Product()
        {
            if (_ProductType!= "Gummy")
                _amountProduct++;
            // _id++;
            _id = Product.CreateId();

        }
       
        public int Price
        {
            get => _price;
            set => _price = value;

        }
        public string ProductType
        {
            get => _ProductType;
            set => _ProductType = value;

        }
        public string GetName()
        {
            return _ProductName;
        }

        public void SetName(string value)
        {
            _ProductName = value;
        }

        public static int amount
        {
            get => _amountProduct;
            set => _amountProduct = value;


        }
        public static int id
        {
            get => _id;

        }
        public int newId
        {
            get => _newid;
            set => _newid = value;

        }
        public static int CreateId()
        {
            _id++;
            return _id;
        }
        
        }
    }

