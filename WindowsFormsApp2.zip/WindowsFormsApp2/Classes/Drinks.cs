﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsApp2
{
    
    class Drinks : Product
    {
        public decimal _liter;
        public bool _alcohol;
        private static int _drinksAmount = 0;
        

       
        public Drinks(int liter, int amount, int price, string productName, bool alcohol)
        {
            
            _liter = Liter;
            _alcohol = alcohol;
            _ProductName = productName;
            _alcohol = true;
            _price = price;
            _drinksAmount = amount;
            _amountToCreat = amount;
            this.Add(this,amount);

        }
        public bool Alcohol
        {
            get => _alcohol;
            set => _alcohol = value;
        }
        public decimal Liter
        {
            get => _liter;
            set => _liter = value;
        }
        public static int drinksAmount
        {
            get => _drinksAmount;
            set => _drinksAmount = value;

        }

    }
}
