﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsApp2
{
    class Snaks:Food
    {
        bool _sweet;
        bool _sour;
        private static int _snaksAmount = 0;

        public Snaks(int price, string productName, bool sweet, bool sour, int amount)
        {
            _price = price;
            _ProductName = productName;
            _sweet = sweet;
            _sour = sour;
            _ProductType = "Snaks";
            this.Add(this,amount);
        }
        public bool Sweet
        {
            get => _sweet;
            set => _sweet = value;

        }
        public bool Sour
        {
            get => _sour;
            set => _sour = value;

        }
        public static int snaksAmount
        {
            get => _snaksAmount;
            set => _snaksAmount = value;

        }
    }
}
