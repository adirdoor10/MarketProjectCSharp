﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.Media;



namespace WindowsFormsApp2
{
    class Stock
    {
        List<Product> menu = new List<Product>();
        int id;
        public Dictionary<int, Product> dic = new Dictionary<int, Product>();

        public void Add(Product p1,int amount)
        {
            for (int i =0;i<amount;i++)
            {
                id = Product.CreateId();
                dic.Add(id, p1);
            }
            
            UpdateManu(p1, true);
            
        }
        public void delete(Product p1)
        {
            id = GetProductId(p1);
            dic.Remove(id);
            UpdateAmount(p1);
            UpdateManu(p1, false);


        }
        public static void UpdateAmount(Product p1)
        {
            Product.amount--;
            if (p1._ProductType=="Drinks")
            {
                Drinks.drinksAmount--;
            }
            if (p1._ProductType == "Snaks")
            {
                Snaks.snaksAmount--;
            }

        }
        
        public static int GetProductId(Product p1)
        {
            return Product.id;

        }
        public void UpdateManu(Product p1, bool add)           // this is the display menu that we will see on form
        {
            bool a = true;
            if (add == true)
            {
                foreach (var item in menu)
                {
                    if (p1._ProductName == item._ProductName)

                        a = false;

                }
                if (a)
                    menu.Add(p1);
            }
            else
                menu.Remove(p1);

        }
        

    }
}
